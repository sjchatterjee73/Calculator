function List(){
	this.head = null;
}
List.prototype.insert = function(){
	var node = {
		value: input,
		next: null
	}

	if(this.head == null){
		this.head = node;		
	}else{
		node.next = this.head;
		this.head = node;		
	}
};

List.prototype.display = function(){
	window.document.myCalculator.display.value = "Last Operation Was: " + this.head.value;
};
List.prototype.traverse = function(count){	
	var flag = 1;
	var temp = this.head;
	var check = false;
	while(temp){
		if(flag++ == count){			
			break;
		}
		temp = temp.next;
	}
	window.document.myCalculator.display.value = "The Traversed Operation Is: " + temp.value;	
	window.document.myCalculator.input.value = temp.value;	
}

List.prototype.getNodes = function(){
	var count = 0;
	var temp = this.head;
	while(temp){
		count++;
		temp = temp.next;
	}
	return count;
}
var ll = new List();
var	count = 1;
var totalNodes = 0;
function MyDriver(val){
	if(val.trim() === "TRAVERSE"){
		ll.traverse(count);
		totalNodes = ll.getNodes();
		if(totalNodes == count)
			count = 1;
		count++;			
		return;
	}
	if(val.trim() === "FORWARD"){		
		ll.traverse(totalNodes);
		totalNodes--;		
		return;
	}
	if(val.trim() === "sin")
		input = "sin("+input+")";
	else if(val.trim() === "sinh")
		input = "sinh("+input+")";
	else if(val.trim() === "tan")
		input = "tan("+input+")";
	else if(val.trim() === "tanh")
		input = "tanh("+input+")";
	else if(val.trim() === "cosh")
		input = "cosh("+input+")";
	else if(val.trim() === "cos")
		input = "cos("+input+")";
	
	ll.insert();
	ll.display();
}
