var input = "";
var operand = [];
var operator = [];
var topOperand = -1, topOperator = -1;

function calculate(val){ 
	if(val.trim() === "SUBMIT"){		
		for(var i=0; i<input.length; i++){
			if(input.charAt(i) == '%'){				
				getMod(input);				
				return;
			}
			if(input.charAt(i) == '!'){
				factorial(input);				
				return;
			}
			if(input.charAt(i) == 'p'){
				getPower();
				return;
			}
		}
		display(input)
		return;
			
	}


	if(val.trim() === "MOD"){
		window.document.myCalculator.input.value += '%';
		return;
	}
	input = window.document.myCalculator.input.value;
	input += val;
	window.document.myCalculator.input.value = input;
}

function getPower(){
	var first = "";
	var second = "";
	var string = window.document.myCalculator.input.value;
	for(var i=0; i<string.length; i++){
		if(string.charAt(i) == 'p')
			break;
		first += string.charAt(i);
		
	}

	for(var i=string.length-1; i>=0; i--){
		if(string.charAt(i) == 'r')
			break;
		second += string.charAt(i);
		
	}

	power(parseInt(first), parseInt(second));
}

function power(a, b){	
	var temp = 1;
	for(var i=0; i<b; i++){
		temp *= a;
	}
	window.document.myCalculator.input.value = temp;	
}

function factorial(num){
	var temp = "";
	for(var i=0; i<num.length; i++){
		if(num.charAt(i) == '!')
			break;

		temp += num.charAt(i);
	}
	input = temp + "!";
	temp = parseInt(temp);
	temp = getFactorial(temp);	
	window.document.myCalculator.input.value = temp;	
}

function getFactorial(temp){
	if(temp <= 0)
		return 1;

	return temp * getFactorial(temp-1);
}
function getMod(numbers){
	var temp = "", temp1 = "";
	var ch = false;
	for(var i=0; i<numbers.length; i++){
		if(!ch && numbers.charAt(i) != '%')
			temp += numbers.charAt(i);			
		else if(numbers.charAt(i) == '%')
			ch = true;
		else if(ch && numbers.charAt(i) != '%')
			temp1 += numbers.charAt(i);
	}

	window.document.myCalculator.input.value = (parseInt(temp) % parseInt(temp1));
}

function operandPush(elem){
	operand[++topOperand] = elem;
}
function operandPop(elem){
	return operand[topOperand--];
}
function operatorPush(item){
	operator[++topOperator] = item;
}
function operatorPeek(){
	return operator[topOperator];
}
function operatorIsEmpty(){
	return (topOperator == -1);
}
function operatorPop(){
	return operator[topOperator--];
}
function applyOp(op, a, b){
	switch(op){
		case '+': return a+b;
		case '-': return b-a;
		case '*': return a*b;
		case '/': return b/a;
	}
}
function isHighPrecedence(a, b){
	if(b == '(')
		return false;	
	var array =[];
	array[0] = '(';
	array[1] = ')';
	array[2] = '/';
	array[3] = '*';
	array[4] = '+';
	array[5] = '-';
	var indexA = 0;
	var indexB = 0;
	for(var i=0; i<array.length; i++){
		if(array[i] === a)
			indexA = i;
		if(array[i] === b)
			indexB = i;
	}

	if(indexA > indexB)
		return true;

	return false;
}
function display(string){
	var number = "";
	var i=0;
	while(i < string.length){
		if(string.charAt(i) >= '0' && string.charAt(i)<='9'){
			number = string.charAt(i) + "";
			i++;
			while(i != string.length && (string.charAt(i) >= '0' && string.charAt(i) <='9')){
				number += string.charAt(i++);
			}
			operandPush(parseInt(number));
		}else{
			if(string.charAt(i) == ')'){
				while(operatorPeek() != '('){
					operandPush(applyOp(operatorPop(), operandPop(), operandPop()));
				}
				operatorPop();
			}else{
				var currentOp = string.charAt(i);
				var lastOp = (operatorIsEmpty() ? '$' : operatorPeek());

				if(lastOp != '$' && isHighPrecedence(currentOp, lastOp)){
					operandPush(applyOp(operatorPop(), operandPop(), operandPop()));	
				}
				operatorPush(string.charAt(i));
			}
			i++;
		}
	}

	while(!operatorIsEmpty()){
		operandPush(applyOp(operatorPop(), operandPop(), operandPop()));
	}
	window.document.myCalculator.input.value = operandPop();
}
