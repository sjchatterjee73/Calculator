function driver(value){
	if(value.trim() === "CLEAR")
		ClearText();		
	
	else if(value.trim() === "BACKSPACE")
		BackSpace();
	else if(value.trim() === "sin" || value.trim() === "sinh" || value.trim() === "tan" || value.trim() === "tanh"
			|| value.trim() === "cos" || value.trim() === "cosh")
		getMath(value);
}

function getMath(value){	
	var temp = "", temp1 = "";
	var string = window.document.myCalculator.input.value;

	for(var i=0; i<string.length; i++){
		if(string.charAt(i)>='0' && string.charAt(i) <= '9')
			temp += string.charAt(i);
		if(string.charAt(i) >='a' && string.charAt(i) <='z')
			temp1 += string.charAt(i);
	}	
	
	if(value.trim() === "sin" && temp1 === "")
		window.document.myCalculator.input.value = Math.sin(parseInt(window.document.myCalculator.input.value));
	else if(value.trim() === "sinh" && temp1 ==="")
		window.document.myCalculator.input.value = Math.sinh(parseInt(window.document.myCalculator.input.value));
	else if(value.trim() === "tan" && temp1 ==="")
		window.document.myCalculator.input.value = Math.tan(parseInt(window.document.myCalculator.input.value));
	else if(value.trim() === "tanh" && temp1 ==="")
		window.document.myCalculator.input.value = Math.tanh(parseInt(window.document.myCalculator.input.value));
	else if(value.trim() === "cos" && temp1 ==="")
		window.document.myCalculator.input.value = Math.cos(parseInt(window.document.myCalculator.input.value));
	else if(value.trim() === "cosh" && temp1 ==="")
		window.document.myCalculator.input.value = Math.cosh(parseInt(window.document.myCalculator.input.value));
	else if(temp1 != ""){		
		if(temp1 === "sin")
			window.document.myCalculator.input.value = Math.sin(parseInt(temp));
		else if(temp1 === "sinh")
			window.document.myCalculator.input.value = Math.sinh(parseInt(temp));
		else if(temp1 === "cos")
			window.document.myCalculator.input.value = Math.cos(parseInt(temp));
		else if(temp1 === "cosh")
			window.document.myCalculator.input.value = Math.cosh(parseInt(temp));
		else if(temp1 === "tan")
			window.document.myCalculator.input.value = Math.tan(parseInt(temp));
		else if(temp1 === "tanh")
			window.document.myCalculator.input.value = Math.tan(parseInt(temp));

		input = temp;
	}
}
function ClearText(){
	window.document.myCalculator.input.value = "";
}

function BackSpace(){
	window.document.myCalculator.input.value = 
	window.document.myCalculator.input.value.substring(0, window.document.myCalculator.input.value.length-1);
}


function getMultiplies(){	
	var temp = parseInt(window.document.myCalculator.input.value);
	var print = "";
	for(var i = 2; i< temp; i++) {
         while(temp%i == 0) {
            print += i +" x ";
            temp = temp/i;
         }
      }
      if(temp >2) {
         print += temp;
      }
      temp = "";
      
      if(print.charAt(print.length-2) == 'x'){      	
      	for(var i=0; i<print.length-3; i++)
      		temp += print.charAt(i);
      }else{
      	temp = print;
      }

      window.document.myCalculator.input.value = temp;
      input = temp;
}