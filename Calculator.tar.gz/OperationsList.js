function List(){
	this.head = null;
}
List.prototype.insert = function(){
	var node = {
		value: input,
		next: null
	}

	if(this.head == null){
		this.head = node;		
	}else{
		node.next = this.head;
		this.head = node;		
	}
};

List.prototype.display = function(){
	window.document.myCalculator.display.value = "Last Operation Was: " + this.head.value;
};
List.prototype.traverse = function(count){	
	var flag = 1;
	var temp = this.head;
	var check = false;
	while(temp){
		if(flag++ == count){			
			break;
		}
		temp = temp.next;
	}
	window.document.myCalculator.display.value = "The Traversed Operation is: " + temp.value;	
	window.document.myCalculator.input.value = temp.value;	
}
var ll = new List();
var count = 1;
function MyDriver(val){
	if(val.trim() === "TRAVERSE"){
		ll.traverse(count);
		count++;		
		return;
	}
	ll.insert();
	ll.display();
	
}
