function driver(value){
	if(value.trim() === "CLEAR")
		ClearText();		
	
	else if(value.trim() === "BACKSPACE")
		BackSpace();

}

function ClearText(){
	window.document.myCalculator.input.value = "";
}

function BackSpace(){
	window.document.myCalculator.input.value = 
	window.document.myCalculator.input.value.substring(0, window.document.myCalculator.input.value.length-1);
}